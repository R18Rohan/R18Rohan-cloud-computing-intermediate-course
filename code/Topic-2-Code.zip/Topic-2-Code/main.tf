# Terraform Configuration: Topic 2 - Containers on AWS

provider "aws" {
  region = "us-east-1"
}

# 1. Amazon ECR Repository
resource "aws_ecr_repository" "app_repo" {
  name                 = "production-web-app"
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }
  tags = { Environment = "production" }
}

# 2. Amazon ECS Cluster
resource "aws_ecs_cluster" "app_cluster" {
  name = "app-production-cluster"
  tags = { Environment = "production" }
}

# 3. ECS Task Definition (Fargate)
resource "aws_ecs_task_definition" "app_task" {
  family                   = "web-app-task-family"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = "256"
  memory                   = "512"

  container_definitions = jsonencode([
    {
      name      = "web-app-container"
      image     = "${aws_ecr_repository.app_repo.repository_url}:latest"
      essential = true
      portMappings = [
        {
          containerPort = 3000
          hostPort      = 3000
        }
      ]
    }
  ])
}

# 4. Application Load Balancer (ALB) & Listeners
resource "aws_lb" "app_alb" {
  name               = "production-app-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = ["sg-12345678"]
  subnets            = ["subnet-11111111", "subnet-22222222"]
}

resource "aws_lb_target_group" "app_tg" {
  name        = "ecs-app-target-group"
  port        = 3000
  protocol    = "HTTP"
  vpc_id      = "vpc-12345678"
  target_type = "ip"

  health_check {
    path                = "/health"
    healthy_threshold   = 3
    unhealthy_threshold = 3
    timeout             = 5
    interval            = 30
  }
}

resource "aws_lb_listener" "http_listener" {
  load_balancer_arn = aws_lb.app_alb.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.app_tg.arn
  }
}

# 5. ECS Fargate Service
resource "aws_ecs_service" "app_service" {
  name            = "web-app-service"
  cluster         = aws_ecs_cluster.app_cluster.id
  task_definition = aws_ecs_task_definition.app_task.arn
  desired_count   = 2
  launch_type     = "FARGATE"

  network_configuration {
    subnets          = ["subnet-33333333"]
    security_groups  = ["sg-12345678"]
    assign_public_ip = true
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.app_tg.arn
    container_name   = "web-app-container"
    container_port   = 3000
  }
}
